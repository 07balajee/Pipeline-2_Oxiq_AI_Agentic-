from typing import List, Tuple
from shared.context.workflow_context import WorkflowContext
from shared.logger.logger import error_logger, workflow_logger

ALLOWED_ENTRY_STATES = ["TechnicalInterviewPending", "TechnicalInterviewCompleted"]


class Validator:
    """
    Validates WorkflowContext parameters for Agent 7.
    Per agent_contracts.md §6 prerequisites: "Interview state is Scheduled
    and transcript files are uploaded" / expected input context of
    `interview_id`, `transcript_text` (or explicit ratings), `technical_criteria`.
    """

    def validate(self, context: WorkflowContext) -> Tuple[bool, List[str]]:
        errors = []
        candidate = context.candidate

        if not candidate:
            errors.append("Candidate context is completely missing.")
            return False, errors

        if not getattr(candidate, "candidate_id", None):
            errors.append("Candidate ID is missing.")
        if not getattr(candidate, "job_id", None):
            errors.append("Job ID is missing.")

        if context.current_state not in ALLOWED_ENTRY_STATES:
            errors.append(
                f"Invalid workflow state for technical evaluation: '{context.current_state}'. "
                f"Expected one of: {ALLOWED_ENTRY_STATES}."
            )

        interview_id = context.step_data.get("interview_id")
        if not interview_id:
            errors.append("step_data.interview_id is missing — required to locate the interview record.")

        has_transcript = bool(context.step_data.get("transcript_text"))
        has_ratings = any(
            context.step_data.get(k) is not None
            for k in ("technical_depth", "problem_solving", "coding_proficiency", "system_design")
        )
        if not has_transcript and not has_ratings:
            errors.append(
                "Neither step_data.transcript_text nor explicit competency ratings were provided — "
                "nothing to evaluate."
            )

        is_valid = len(errors) == 0
        if not is_valid:
            error_logger.error(
                "Agent 7 context validation failed.",
                trace_id=context.workflow_id,
                metadata={"validation_errors": errors}
            )
        else:
            workflow_logger.info("Agent 7 Context Validation Passed.", trace_id=context.workflow_id)

        return is_valid, errors

    def validate_interview_payload(self, interview_payload: dict, workflow_id: str) -> Tuple[bool, List[str]]:
        errors = []
        if not interview_payload:
            errors.append("Interview record could not be retrieved from the database.")
            return False, errors

        if interview_payload.get("status") not in ("Scheduled", "TECH_EVALUATED"):
            errors.append(
                f"Interview status is '{interview_payload.get('status')}', expected 'Scheduled'."
            )

        is_valid = len(errors) == 0
        if not is_valid:
            error_logger.error(
                "Agent 7 interview payload validation failed.",
                trace_id=workflow_id,
                metadata={"interview_errors": errors}
            )
        return is_valid, errors
