import uuid
from datetime import datetime, timezone
from typing import List, Optional

from agents.agent7.models import CompetencyScore, Recommendation, TechnicalScorecard


class ScorecardBuilder:
    """Builder pattern implementation for compiling the final TechnicalScorecard."""

    def __init__(self):
        self._evaluation_id = None
        self._interview_id = None
        self._candidate_id = None
        self._scores: List[CompetencyScore] = []
        self._evaluation_notes = ""
        self._recommendation: Optional[Recommendation] = None
        self._overall_score = None
        self._confidence = 1.0
        self._source = "structured_ratings"

    def with_interview(self, interview_id: str, candidate_id: str) -> "ScorecardBuilder":
        self._interview_id = interview_id
        self._candidate_id = candidate_id
        self._evaluation_id = f"eval-{uuid.uuid4()}"
        return self

    def with_scores(self, scores: List[CompetencyScore]) -> "ScorecardBuilder":
        self._scores = scores
        return self

    def with_notes(self, notes: str) -> "ScorecardBuilder":
        self._evaluation_notes = notes
        return self

    def with_recommendation(self, recommendation: Recommendation) -> "ScorecardBuilder":
        self._recommendation = recommendation
        return self

    def with_overall_score(self, overall_score: float) -> "ScorecardBuilder":
        self._overall_score = overall_score
        return self

    def with_confidence(self, confidence: float) -> "ScorecardBuilder":
        self._confidence = confidence
        return self

    def with_source(self, source: str) -> "ScorecardBuilder":
        self._source = source
        return self

    def build(self) -> TechnicalScorecard:
        return TechnicalScorecard(
            evaluation_id=self._evaluation_id or f"eval-{uuid.uuid4()}",
            interview_id=self._interview_id or "",
            candidate_id=self._candidate_id or "",
            scores=self._scores,
            evaluation_notes=self._evaluation_notes,
            recommendation=self._recommendation or Recommendation.FAIL,
            overall_score=self._overall_score if self._overall_score is not None else 0.0,
            confidence=self._confidence,
            source=self._source,
            completed_at=datetime.now(timezone.utc).isoformat(),
        )
