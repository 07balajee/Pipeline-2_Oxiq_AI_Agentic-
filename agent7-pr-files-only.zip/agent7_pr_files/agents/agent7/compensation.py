import datetime
from typing import Any, Dict
from shared.logger.logger import workflow_logger
from agents.agent7.tools import Agent7ToolsAdapter


class CompensationManager:
    """
    Rolls back prepared-but-uncommitted database transactions if Agent 7's
    persistence step fails partway through (e.g. the evaluation insert
    succeeds but the interview status update fails).
    """

    @staticmethod
    def compensate(context: Any, insert_prep: Dict[str, Any] = None, status_update_prep: Dict[str, Any] = None):
        workflow_logger.info("Initializing Agent 7 compensation sequence...", trace_id=context.workflow_id)

        if insert_prep:
            workflow_logger.info(
                "Compensate: Rolling back technical_evaluations insert preparation...",
                trace_id=context.workflow_id
            )
            Agent7ToolsAdapter.rollback_transaction(insert_prep, context.workflow_id, context.metadata)

        if status_update_prep:
            workflow_logger.info(
                "Compensate: Rolling back interview status update preparation...",
                trace_id=context.workflow_id
            )
            Agent7ToolsAdapter.rollback_transaction(status_update_prep, context.workflow_id, context.metadata)

        context.step_data.pop("db_evaluation_insert_prepared", None)
        context.step_data.pop("db_status_update_prepared", None)

        if "compensation_log" not in context.metadata:
            context.metadata["compensation_log"] = []
        context.metadata["compensation_log"].append({
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "rolled_back_evaluation_insert": bool(insert_prep),
            "rolled_back_status_update": bool(status_update_prep),
        })

        workflow_logger.info("Agent 7 compensation sequence completed.", trace_id=context.workflow_id)
