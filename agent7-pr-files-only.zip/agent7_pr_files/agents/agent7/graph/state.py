from typing import TypedDict, Optional, Dict, Any, List
from shared.context.workflow_context import WorkflowContext
from schemas.agent_response import AgentResponse
from agents.agent7.models import TechnicalScorecard


class Agent7GraphState(TypedDict):
    """
    State definition for the Agent 7 LangGraph orchestrator.
    Authoritative checkpoint variables reside inside context.step_data;
    this dict is the per-invocation working scratch space.
    """
    workflow_context: WorkflowContext

    candidate_context: Optional[Dict[str, Any]]
    job_context: Optional[Dict[str, Any]]
    interview_context: Optional[Dict[str, Any]]

    draft_ratings: Optional[Dict[str, Any]]
    scorecard: Optional[TechnicalScorecard]

    db_evaluation_insert_prepared: Optional[Dict[str, Any]]
    db_status_update_prepared: Optional[Dict[str, Any]]

    retry_counts: Dict[str, int]

    last_error: Optional[str]
    failure_category: Optional[str]
    failed_operation: Optional[str]
    route_action: Optional[str]
    warnings: List[str]

    agent_response: Optional[AgentResponse]
