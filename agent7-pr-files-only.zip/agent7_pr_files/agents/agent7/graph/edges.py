from agents.agent7.graph.state import Agent7GraphState


def route_after_intake(state: Agent7GraphState) -> str:
    if state.get("last_error"):
        return "build_response_node"
    return "validate_node"


def route_after_validate(state: Agent7GraphState) -> str:
    if state.get("last_error"):
        return "build_response_node"
    return "retrieve_database_context_node"


def route_after_db_read(state: Agent7GraphState) -> str:
    if state.get("route_action") == "RETRY":
        return "retrieve_database_context_node"
    if state.get("last_error"):
        return "build_response_node"
    return "score_node"


def route_after_score(state: Agent7GraphState) -> str:
    if state.get("last_error"):
        return "build_response_node"
    return "hitl_gate_node"


def route_after_hitl_gate(state: Agent7GraphState) -> str:
    if state.get("last_error"):
        return "build_response_node"
    if state.get("route_action") == "PAUSE_FOR_SIGNOFF":
        return "build_response_node"
    return "prepare_database_node"


def route_after_commit(state: Agent7GraphState) -> str:
    if state.get("last_error"):
        return "build_response_node"
    return "log_analytics_node"
