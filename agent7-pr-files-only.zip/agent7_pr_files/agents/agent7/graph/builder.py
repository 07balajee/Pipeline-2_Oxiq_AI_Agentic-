from langgraph.graph import StateGraph, START, END
from agents.agent7.graph.state import Agent7GraphState
from agents.agent7.graph.nodes import (
    intake_node, validate_node, retrieve_database_context_node, score_node,
    hitl_gate_node, prepare_database_node, commit_database_node,
    log_analytics_node, build_response_node
)
from agents.agent7.graph.edges import (
    route_after_intake, route_after_validate, route_after_db_read,
    route_after_score, route_after_hitl_gate, route_after_commit
)


def compile_agent_graph():
    """Assembles and compiles the stateless Agent 7 technical evaluation orchestrator graph."""
    workflow = StateGraph(Agent7GraphState)

    # 1. Register Nodes
    workflow.add_node("intake_node", intake_node)
    workflow.add_node("validate_node", validate_node)
    workflow.add_node("retrieve_database_context_node", retrieve_database_context_node)
    workflow.add_node("score_node", score_node)
    workflow.add_node("hitl_gate_node", hitl_gate_node)
    workflow.add_node("prepare_database_node", prepare_database_node)
    workflow.add_node("commit_database_node", commit_database_node)
    workflow.add_node("log_analytics_node", log_analytics_node)
    workflow.add_node("build_response_node", build_response_node)

    # 2. Static Edges
    workflow.add_edge(START, "intake_node")
    workflow.add_edge("prepare_database_node", "commit_database_node")
    workflow.add_edge("log_analytics_node", "build_response_node")
    workflow.add_edge("build_response_node", END)

    # 3. Conditional Edges
    workflow.add_conditional_edges(
        "intake_node", route_after_intake,
        {"validate_node": "validate_node", "build_response_node": "build_response_node"}
    )
    workflow.add_conditional_edges(
        "validate_node", route_after_validate,
        {"retrieve_database_context_node": "retrieve_database_context_node", "build_response_node": "build_response_node"}
    )
    workflow.add_conditional_edges(
        "retrieve_database_context_node", route_after_db_read,
        {
            "score_node": "score_node",
            "retrieve_database_context_node": "retrieve_database_context_node",
            "build_response_node": "build_response_node",
        }
    )
    workflow.add_conditional_edges(
        "score_node", route_after_score,
        {"hitl_gate_node": "hitl_gate_node", "build_response_node": "build_response_node"}
    )
    workflow.add_conditional_edges(
        "hitl_gate_node", route_after_hitl_gate,
        {"prepare_database_node": "prepare_database_node", "build_response_node": "build_response_node"}
    )
    workflow.add_conditional_edges(
        "commit_database_node", route_after_commit,
        {"log_analytics_node": "log_analytics_node", "build_response_node": "build_response_node"}
    )

    return workflow.compile()
