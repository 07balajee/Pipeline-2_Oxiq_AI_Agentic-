import asyncio
from typing import Dict, Any

from langchain_core.runnables import RunnableConfig

from shared.logger.logger import workflow_logger
from agents.agent7.validator import Validator
from agents.agent7.tools import Agent7ToolsAdapter
from agents.agent7.response_builder import ResponseBuilder
from agents.agent7.builder import ScorecardBuilder
from agents.agent7.compensation import CompensationManager
from agents.agent7.scoring import compute_scorecard, recommend, DEFAULT_WEIGHTS
from agents.agent7.groq_client import parse_transcript
from agents.agent7.models import Recommendation
from agents.agent7.graph.state import Agent7GraphState

MAX_LOCAL_RETRIES = 3
CONFIDENCE_ESCALATION_THRESHOLD = 0.70
COMPETENCY_KEYS = ["technical_depth", "problem_solving", "coding_proficiency", "system_design"]


def _run_async(coro):
    """Runs an async coroutine from inside a sync LangGraph node."""
    return asyncio.run(coro)


def intake_node(state: Agent7GraphState, config: RunnableConfig) -> Dict[str, Any]:
    context = state["workflow_context"]
    workflow_logger.info("Initializing Agent 7 technical evaluation graph flow...", trace_id=context.workflow_id)
    return {
        "retry_counts": {"database_read": 0, "database_commit": 0},
        "candidate_context": None,
        "job_context": None,
        "interview_context": None,
        "draft_ratings": None,
        "scorecard": None,
        "last_error": None,
        "failure_category": None,
        "failed_operation": None,
        "warnings": [],
        "route_action": None,
    }


def validate_node(state: Agent7GraphState, config: RunnableConfig) -> Dict[str, Any]:
    context = state["workflow_context"]
    validator = Validator()
    is_valid, validation_errors = validator.validate(context)

    if not is_valid:
        workflow_logger.info(f"Agent 7 intake validation failed: {validation_errors}", trace_id=context.workflow_id)
        return {
            "last_error": "; ".join(validation_errors),
            "failure_category": "TERMINAL",
            "failed_operation": "validate",
        }
    return {"last_error": None, "route_action": None}


def retrieve_database_context_node(state: Agent7GraphState, config: RunnableConfig) -> Dict[str, Any]:
    """MCP Action: Database reads for candidate, job, and interview context."""
    context = state["workflow_context"]
    retry_counts = dict(state["retry_counts"])

    cand_resp = Agent7ToolsAdapter.read_candidate(context.candidate.candidate_id, context.workflow_id, context.metadata)
    if cand_resp.status != "SUCCESS":
        tries = retry_counts.get("database_read", 0)
        if tries < MAX_LOCAL_RETRIES:
            retry_counts["database_read"] = tries + 1
            return {"retry_counts": retry_counts, "route_action": "RETRY", "last_error": None}
        return {
            "last_error": f"Database candidate read failed: {cand_resp.errors}",
            "failure_category": "TERMINAL", "failed_operation": "database_read",
        }

    job_resp = Agent7ToolsAdapter.read_job(context.candidate.job_id, context.workflow_id, context.metadata)
    if job_resp.status != "SUCCESS":
        tries = retry_counts.get("database_read", 0)
        if tries < MAX_LOCAL_RETRIES:
            retry_counts["database_read"] = tries + 1
            return {"retry_counts": retry_counts, "route_action": "RETRY", "last_error": None}
        return {
            "last_error": f"Database job read failed: {job_resp.errors}",
            "failure_category": "TERMINAL", "failed_operation": "database_read",
        }

    interview_id = context.step_data.get("interview_id")
    interview_resp = Agent7ToolsAdapter.read_interview(interview_id, context.workflow_id, context.metadata)
    if interview_resp.status != "SUCCESS":
        return {
            "last_error": f"Database interview read failed: {interview_resp.errors}",
            "failure_category": "TERMINAL", "failed_operation": "database_read",
        }

    validator = Validator()
    is_valid, interview_errors = validator.validate_interview_payload(interview_resp.payload, context.workflow_id)
    if not is_valid:
        return {
            "last_error": "; ".join(interview_errors),
            "failure_category": "TERMINAL", "failed_operation": "database_read",
        }

    return {
        "candidate_context": cand_resp.payload,
        "job_context": job_resp.payload,
        "interview_context": interview_resp.payload,
        "last_error": None,
        "route_action": None,
    }


def score_node(state: Agent7GraphState, config: RunnableConfig) -> Dict[str, Any]:
    """
    Determines whether structured ratings were supplied directly, or need to
    be transcribed from a free-text transcript via Groq. Either way, the
    final overall_score/recommendation always comes from the fixed formula
    in agents/agent7/scoring.py — Groq only ever proposes the raw category
    numbers, never the verdict.
    """
    context = state["workflow_context"]
    job_context = state.get("job_context") or {}

    explicit_ratings = {k: context.step_data.get(k) for k in COMPETENCY_KEYS}
    has_explicit = any(v is not None for v in explicit_ratings.values())

    if has_explicit:
        workflow_logger.info("Agent 7: using explicit structured ratings from step_data.", trace_id=context.workflow_id)
        draft = {**explicit_ratings, "evaluation_notes": context.step_data.get("evaluation_notes", ""),
                 "confidence": 1.0, "source": "structured_ratings"}
        return {"draft_ratings": draft, "last_error": None, "route_action": None}

    transcript_text = context.step_data.get("transcript_text")
    if not transcript_text:
        return {
            "last_error": "No structured ratings or transcript_text available to score.",
            "failure_category": "TERMINAL", "failed_operation": "score",
        }

    workflow_logger.info("Agent 7: transcribing transcript_text via Groq...", trace_id=context.workflow_id)
    technical_criteria = job_context.get("technical_criteria")
    parsed = _run_async(parse_transcript(transcript_text, technical_criteria))
    draft = {**{k: parsed.get(k) for k in COMPETENCY_KEYS},
             "evaluation_notes": parsed.get("evaluation_notes", ""),
             "confidence": parsed.get("confidence", 0.3),
             "source": "transcript_parsed"}

    if not any(draft[k] is not None for k in COMPETENCY_KEYS):
        return {
            "last_error": "Transcript parsing produced no usable competency ratings.",
            "failure_category": "TERMINAL", "failed_operation": "score",
        }

    return {"draft_ratings": draft, "last_error": None, "route_action": None}


def hitl_gate_node(state: Agent7GraphState, config: RunnableConfig) -> Dict[str, Any]:
    """
    Per workflow_contracts.md §7 "Technical Evaluation Review": a transcript-
    derived draft scorecard always pauses for interviewer sign-off before
    being persisted, unless the resume carries an explicit approval flag.
    Low-confidence structured submissions are also gated.
    """
    context = state["workflow_context"]
    draft = state["draft_ratings"]

    ratings = {k: draft.get(k) for k in COMPETENCY_KEYS}
    try:
        overall, scores, weights_used = compute_scorecard(ratings, DEFAULT_WEIGHTS)
    except ValueError as e:
        return {"last_error": str(e), "failure_category": "TERMINAL", "failed_operation": "score"}

    recommendation = recommend(overall)
    interviewer_approved = bool(context.metadata.get("interviewer_approved"))
    needs_signoff = (draft.get("source") == "transcript_parsed") or (draft.get("confidence", 1.0) < CONFIDENCE_ESCALATION_THRESHOLD)

    interview_id = context.step_data.get("interview_id")
    candidate_id = context.candidate.candidate_id

    scorecard = (
        ScorecardBuilder()
        .with_interview(interview_id, candidate_id)
        .with_scores(scores)
        .with_notes(draft.get("evaluation_notes", ""))
        .with_recommendation(recommendation)
        .with_overall_score(overall)
        .with_confidence(draft.get("confidence", 1.0))
        .with_source(draft.get("source", "structured_ratings"))
        .build()
    )

    if needs_signoff and not interviewer_approved:
        workflow_logger.info(
            "Agent 7: draft scorecard requires interviewer sign-off before persistence.",
            trace_id=context.workflow_id
        )
        return {
            "scorecard": scorecard,
            "last_error": None,
            "route_action": "PAUSE_FOR_SIGNOFF",
        }

    return {"scorecard": scorecard, "last_error": None, "route_action": None}


def prepare_database_node(state: Agent7GraphState, config: RunnableConfig) -> Dict[str, Any]:
    context = state["workflow_context"]
    scorecard = state["scorecard"]

    insert_prep = context.step_data.get("db_evaluation_insert_prepared")
    status_prep = context.step_data.get("db_status_update_prepared")

    write_key = f"pl2:{context.candidate.candidate_id}:agent7:{scorecard.interview_id}"

    if not insert_prep:
        record = {
            "evaluation_id": scorecard.evaluation_id,
            "interview_id": scorecard.interview_id,
            "scores_json": scorecard.scores_json(),
            "evaluation_notes": scorecard.evaluation_notes,
            "recommendation": scorecard.recommendation.value,
            "completed_at": scorecard.completed_at,
        }
        insert_resp = Agent7ToolsAdapter.prepare_evaluation_insert(
            record, context.workflow_id, idempotency_key=write_key, metadata=context.metadata
        )
        if insert_resp.status != "SUCCESS":
            return {
                "last_error": f"technical_evaluations insert preparation failed: {insert_resp.errors}",
                "failure_category": "TERMINAL", "failed_operation": "database_prepare",
            }
        insert_prep = insert_resp.payload
        context.step_data["db_evaluation_insert_prepared"] = insert_prep

    if not status_prep:
        status_resp = Agent7ToolsAdapter.prepare_interview_status_update(
            scorecard.interview_id, "TECH_EVALUATED", context.workflow_id,
            idempotency_key=write_key, metadata=context.metadata
        )
        if status_resp.status != "SUCCESS":
            return {
                "last_error": f"interviews.status update preparation failed: {status_resp.errors}",
                "failure_category": "TERMINAL", "failed_operation": "database_prepare",
            }
        status_prep = status_resp.payload
        context.step_data["db_status_update_prepared"] = status_prep

    return {
        "db_evaluation_insert_prepared": insert_prep,
        "db_status_update_prepared": status_prep,
        "last_error": None, "route_action": None,
    }


def commit_database_node(state: Agent7GraphState, config: RunnableConfig) -> Dict[str, Any]:
    context = state["workflow_context"]
    insert_prep = state["db_evaluation_insert_prepared"] or context.step_data.get("db_evaluation_insert_prepared")
    status_prep = state["db_status_update_prepared"] or context.step_data.get("db_status_update_prepared")

    if context.step_data.get("db_committed"):
        workflow_logger.info("Idempotency Checkpoint: Agent 7 database transaction already committed.", trace_id=context.workflow_id)
        return {"last_error": None, "route_action": None}

    commit_insert_resp = Agent7ToolsAdapter.commit_transaction(insert_prep, context.workflow_id, context.metadata)
    if commit_insert_resp.status != "SUCCESS":
        CompensationManager.compensate(context, insert_prep, status_prep)
        return {
            "last_error": f"Commit for technical_evaluations insert failed: {commit_insert_resp.errors}",
            "failure_category": "COMPENSATION_REQUIRED", "failed_operation": "database_commit",
        }

    commit_status_resp = Agent7ToolsAdapter.commit_transaction(status_prep, context.workflow_id, context.metadata)
    if commit_status_resp.status != "SUCCESS":
        CompensationManager.compensate(context, insert_prep, status_prep)
        return {
            "last_error": f"Commit for interview status update failed: {commit_status_resp.errors}",
            "failure_category": "COMPENSATION_REQUIRED", "failed_operation": "database_commit",
        }

    context.step_data["db_committed"] = True
    return {"last_error": None, "route_action": None}


def log_analytics_node(state: Agent7GraphState, config: RunnableConfig) -> Dict[str, Any]:
    """Best-effort, non-terminal: Analytics MCP failures never block the workflow."""
    context = state["workflow_context"]
    scorecard = state["scorecard"]
    try:
        Agent7ToolsAdapter.log_metrics(
            trace_id=context.workflow_id,
            agent_name="agent7",
            metrics_payload={
                "interview_id": scorecard.interview_id,
                "overall_score": scorecard.overall_score,
                "recommendation": scorecard.recommendation.value,
                "source": scorecard.source,
            },
            workflow_id=context.workflow_id,
            metadata=context.metadata,
        )
    except Exception as e:
        workflow_logger.info(f"Agent 7: Analytics MCP logging failed non-fatally: {e}", trace_id=context.workflow_id)
    return {"last_error": None, "route_action": None}


def build_response_node(state: Agent7GraphState, config: RunnableConfig) -> Dict[str, Any]:
    context = state["workflow_context"]
    last_error = state.get("last_error")
    route_action = state.get("route_action")

    if route_action == "PAUSE_FOR_SIGNOFF":
        scorecard = state["scorecard"]
        context.step_data["draft_scorecard"] = scorecard.model_dump(mode="json")
        response = (
            ResponseBuilder()
            .with_status("SUCCESS")
            .with_event_and_state(None, "WorkflowPaused")
            .with_summary(
                f"Draft technical scorecard for {context.candidate.name} requires interviewer "
                f"sign-off before it can be persisted (overall={scorecard.overall_score}/10, "
                f"recommendation={scorecard.recommendation.value})."
            )
            .with_action("AWAIT_INTERVIEWER_SIGNOFF")
            .with_metadata({
                "draft_scorecard": scorecard.model_dump(mode="json"),
                "confidence": scorecard.confidence,
                "source": scorecard.source,
            })
            .build()
        )
        workflow_logger.info("Agent 7 paused: awaiting interviewer sign-off.", trace_id=context.workflow_id)
        return {"agent_response": response}

    if last_error:
        builder = (
            ResponseBuilder()
            .with_status("FAILED")
            .with_errors([last_error])
            .with_warnings(state.get("warnings") or [])
            .with_summary(f"Agent 7 execution failed on operation: '{state.get('failed_operation')}'")
            .with_metadata({
                "failed_operation": state.get("failed_operation"),
                "failure_category": state.get("failure_category"),
            })
        )
        context.metadata["last_execution_error"] = last_error
        return {"agent_response": builder.build()}

    scorecard = state["scorecard"]
    context.step_data["technical_scorecard"] = scorecard.model_dump(mode="json")
    context.step_data["technical_recommendation"] = scorecard.recommendation.value

    summary_msg = (
        f"Technical scorecard finalized for {context.candidate.name}: "
        f"overall={scorecard.overall_score}/10, recommendation={scorecard.recommendation.value}."
    )

    response = (
        ResponseBuilder()
        .with_status("SUCCESS")
        .with_event_and_state("TechnicalScoreSubmitted", "TechnicalInterviewCompleted")
        .with_warnings(state.get("warnings") or [])
        .with_summary(summary_msg)
        .with_metadata({
            **scorecard.model_dump(mode="json"),
        })
        .build()
    )
    workflow_logger.info("Agent 7 technical evaluation completed successfully.", trace_id=context.workflow_id)
    return {"agent_response": response}
