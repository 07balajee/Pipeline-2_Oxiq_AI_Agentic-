from typing import Any, Dict
from shared.registry.tool_registry import tool_registry
from schemas.mcp_response import MCPResponse


class Agent7ToolsAdapter:
    """
    Thin adapter mapping Agent 7 helper invocations to MCP Client instances
    resolved dynamically from the ToolRegistry. Per agent_contracts.md §6,
    Agent 7's allowed MCPs are: Database MCP, Resume MCP, Analytics MCP.
    """

    @staticmethod
    def read_candidate(candidate_id: str, workflow_id: str, metadata: Dict[str, Any] = None) -> MCPResponse:
        client_cls = tool_registry.get_tool("database_mcp")
        return client_cls().execute(
            action="read_candidate", candidate_id=candidate_id, workflow_id=workflow_id, metadata=metadata
        )

    @staticmethod
    def read_job(job_id: str, workflow_id: str, metadata: Dict[str, Any] = None) -> MCPResponse:
        client_cls = tool_registry.get_tool("database_mcp")
        return client_cls().execute(
            action="read_job", job_id=job_id, workflow_id=workflow_id, metadata=metadata
        )

    @staticmethod
    def read_interview(interview_id: str, workflow_id: str, metadata: Dict[str, Any] = None) -> MCPResponse:
        client_cls = tool_registry.get_tool("database_mcp")
        return client_cls().execute(
            action="read_interview", interview_id=interview_id, workflow_id=workflow_id, metadata=metadata
        )

    @staticmethod
    def get_resume_summary(resume_url: str, workflow_id: str, metadata: Dict[str, Any] = None) -> MCPResponse:
        client_cls = tool_registry.get_tool("resume_mcp")
        return client_cls().execute(
            action="get_resume_summary", resume_url=resume_url, workflow_id=workflow_id, metadata=metadata
        )

    @staticmethod
    def prepare_evaluation_insert(record: Dict[str, Any], workflow_id: str,
                                   idempotency_key: str = None, metadata: Dict[str, Any] = None) -> MCPResponse:
        client_cls = tool_registry.get_tool("database_mcp")
        return client_cls().execute(
            action="prepare_insert", table_name="technical_evaluations", record=record,
            workflow_id=workflow_id, idempotency_key=idempotency_key, metadata=metadata
        )

    @staticmethod
    def prepare_interview_status_update(interview_id: str, new_status: str, workflow_id: str,
                                         idempotency_key: str = None, metadata: Dict[str, Any] = None) -> MCPResponse:
        client_cls = tool_registry.get_tool("database_mcp")
        return client_cls().execute(
            action="prepare_interview_status_update", interview_id=interview_id, new_status=new_status,
            workflow_id=workflow_id, idempotency_key=idempotency_key, metadata=metadata
        )

    @staticmethod
    def commit_transaction(prepared_payload: Dict[str, Any], workflow_id: str, metadata: Dict[str, Any] = None) -> MCPResponse:
        client_cls = tool_registry.get_tool("database_mcp")
        return client_cls().execute(
            action="commit", prepared_payload=prepared_payload, workflow_id=workflow_id, metadata=metadata
        )

    @staticmethod
    def rollback_transaction(prepared_payload: Dict[str, Any], workflow_id: str, metadata: Dict[str, Any] = None) -> MCPResponse:
        client_cls = tool_registry.get_tool("database_mcp")
        return client_cls().execute(
            action="rollback", prepared_payload=prepared_payload, workflow_id=workflow_id, metadata=metadata
        )

    @staticmethod
    def log_metrics(trace_id: str, agent_name: str, metrics_payload: Dict[str, Any], workflow_id: str,
                     metadata: Dict[str, Any] = None) -> MCPResponse:
        client_cls = tool_registry.get_tool("analytics_mcp")
        return client_cls().execute(
            action="log_metrics", trace_id=trace_id, agent_name=agent_name,
            metrics_payload=metrics_payload, workflow_id=workflow_id, metadata=metadata
        )
