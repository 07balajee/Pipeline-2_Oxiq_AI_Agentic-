from shared.interfaces.agent import Agent
from schemas.agent_response import AgentResponse
from shared.context.workflow_context import WorkflowContext
from agents.agent7.graph import compile_agent_graph


class TechnicalInterviewAgent(Agent):
    """
    Agent 7: Technical Interview Assessment.

    Parses technical interview transcripts/notes against a role's technical
    criteria and compiles a competency scorecard, per agent_contracts.md §6.

    Scoring is always deterministic (agents/agent7/scoring.py, a fixed
    weighted formula) — Groq is only used to transcribe a free-text
    transcript into the same structured rating fields a human would type
    directly (agents/agent7/groq_client.py), and any transcript-derived
    draft is routed through a WorkflowPaused / interviewer sign-off gate
    (workflow_contracts.md §7) before it is ever persisted.
    """
    def __init__(self):
        self.graph = compile_agent_graph()

    def run(self, context: WorkflowContext) -> AgentResponse:
        try:
            context.metadata.pop("last_execution_error", None)

            initial_state = {
                "workflow_context": context,
                "candidate_context": None,
                "job_context": None,
                "interview_context": None,
                "draft_ratings": None,
                "scorecard": None,
                "db_evaluation_insert_prepared": None,
                "db_status_update_prepared": None,
                "retry_counts": {},
                "last_error": None,
                "failure_category": None,
                "failed_operation": None,
                "route_action": None,
                "warnings": [],
                "agent_response": None,
            }

            final_state = self.graph.invoke(initial_state)

            updated_ctx = final_state.get("workflow_context")
            if updated_ctx:
                context.step_data.update(updated_ctx.step_data)
                context.metadata.update(updated_ctx.metadata)

            response = final_state.get("agent_response")
            if not response:
                from agents.agent7.response_builder import ResponseBuilder
                response = (
                    ResponseBuilder()
                    .with_status("FAILED")
                    .with_summary("No response returned from Agent 7 graph orchestration.")
                    .build()
                )

            if response.execution_status != "SUCCESS":
                err_msg = response.errors[0] if response.errors else "Unknown failure"
                context.metadata["last_execution_error"] = err_msg

            return response

        except Exception as e:
            context.metadata["last_execution_error"] = str(e)
            from agents.agent7.response_builder import ResponseBuilder
            return (
                ResponseBuilder()
                .with_status("FAILED")
                .with_errors([str(e)])
                .with_summary("Execution exception inside Agent 7 technical evaluation.")
                .build()
            )
