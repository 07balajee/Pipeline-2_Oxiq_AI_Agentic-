"""
Groq (fast LPU inference, OpenAI-compatible API — https://console.groq.com) client
scoped to Agent 7's one legitimate LLM use case, per agent_contracts.md §6:
"Parses interview transcripts and notes against technical criteria."

Scope discipline: this module TRANSCRIBES an interviewer's free-text transcript
into the same structured 0-10 rating fields a human would type directly. It
never decides the pass/fail recommendation or the overall_score — those always
come from agents/agent7/scoring.py's fixed formula. Every transcript-derived
result is treated as a DRAFT requiring interviewer sign-off (WorkflowPaused,
per workflow_contracts.md §7) before anything is persisted.

If GROQ_API_KEY is unset, falls back to a conservative regex-based extractor
so the agent still runs (useful for local dev/tests without a live key).
"""
from __future__ import annotations

import json
import os
import re
from typing import Optional

import httpx

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_API_BASE = os.getenv("GROQ_API_BASE", "https://api.groq.com/openai/v1")
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
GROQ_TIMEOUT_S = float(os.getenv("GROQ_TIMEOUT_S", "30"))

RATING_FIELDS = ["technical_depth", "problem_solving", "coding_proficiency", "system_design"]


class GroqUnavailable(Exception):
    pass


async def _chat(system: str, user: str) -> str:
    if not GROQ_API_KEY:
        raise GroqUnavailable("GROQ_API_KEY not set")

    payload = {
        "model": GROQ_MODEL,
        "temperature": 0,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    }
    headers = {"Authorization": f"Bearer {GROQ_API_KEY}", "Content-Type": "application/json"}

    async with httpx.AsyncClient(timeout=GROQ_TIMEOUT_S) as client:
        resp = await client.post(f"{GROQ_API_BASE}/chat/completions", json=payload, headers=headers)
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"]


_SYSTEM_PROMPT = """You transcribe a technical interview transcript into structured, PROPOSED
0-10 competency ratings against the given technical criteria. You do not evaluate the candidate
yourself — you only extract what the transcript already shows about their performance. If a
category isn't addressed in the transcript, or you can't confidently infer a 0-10 rating, return
null for that field rather than guessing.

Respond ONLY with a JSON object of this exact shape, no extra keys, no prose:
{
  "technical_depth": <0-10 float or null>,
  "problem_solving": <0-10 float or null>,
  "coding_proficiency": <0-10 float or null>,
  "system_design": <0-10 float or null>,
  "evaluation_notes": "<2-4 sentence neutral summary of what the transcript shows>",
  "confidence": <float 0.0-1.0, your confidence these ratings faithfully match the transcript>
}
"""


def _fallback_parse(transcript_text: str) -> dict:
    """No-LLM fallback: conservative regex catching explicit numeric mentions near keywords."""
    out = {f: None for f in RATING_FIELDS}
    pattern = re.compile(
        r"(technical|problem[- ]solving|coding|system[- ]design)\D{0,20}?(\d{1,2}(?:\.\d)?)\s*(?:/\s*10)?\b",
        re.IGNORECASE,
    )
    key_map = {
        "technical": "technical_depth",
        "problem-solving": "problem_solving",
        "problem solving": "problem_solving",
        "coding": "coding_proficiency",
        "system-design": "system_design",
        "system design": "system_design",
    }
    for m in pattern.finditer(transcript_text):
        key = key_map.get(m.group(1).lower())
        val = float(m.group(2))
        if key and 0 <= val <= 10:
            out[key] = val
    return {
        **out,
        "evaluation_notes": "Auto-extracted via regex fallback (Groq unavailable) — low confidence by design.",
        "confidence": 0.3,
    }


async def parse_transcript(transcript_text: str, technical_criteria: Optional[list] = None) -> dict:
    """
    Returns dict with RATING_FIELDS + 'evaluation_notes' + 'confidence'.
    Caller (agents/agent7/graph/nodes.py) treats this as a DRAFT requiring
    interviewer sign-off — never writes it to the database unconfirmed.
    """
    criteria_hint = f"\nTechnical criteria for this role: {', '.join(technical_criteria)}" if technical_criteria else ""
    user_msg = f"Transcript:\n{transcript_text}{criteria_hint}"
    try:
        raw = await _chat(_SYSTEM_PROMPT, user_msg)
        parsed = json.loads(raw)
        for f in RATING_FIELDS:
            v = parsed.get(f)
            if v is not None:
                try:
                    v = float(v)
                    parsed[f] = v if 0 <= v <= 10 else None
                except (TypeError, ValueError):
                    parsed[f] = None
        parsed["confidence"] = float(parsed.get("confidence", 0.5))
        parsed.setdefault("evaluation_notes", "")
        return parsed
    except GroqUnavailable:
        return _fallback_parse(transcript_text)
    except Exception:
        return _fallback_parse(transcript_text)
