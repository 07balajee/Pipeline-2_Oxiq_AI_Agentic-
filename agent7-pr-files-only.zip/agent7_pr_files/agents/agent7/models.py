from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class Recommendation(str, Enum):
    """Matches database_contracts.md: technical_evaluations.recommendation (varchar: PASS, FAIL)."""
    PASS = "PASS"
    FAIL = "FAIL"


class CompetencyScore(BaseModel):
    """
    A single scored category within the scorecard (e.g. 'coding_proficiency').
    Score is on a 0-10 scale, matching the values the dummy stub used
    (agents/agent7/agent.py before this implementation), kept for continuity
    with anything already consuming that shape downstream.
    """
    category: str = Field(..., description="Technical competency category name")
    score: float = Field(..., ge=0, le=10, description="Score on a 0-10 scale")
    rationale: Optional[str] = Field(None, description="Short justification for the score")


class TechnicalScorecard(BaseModel):
    """
    Compiled domain model representing the final technical evaluation,
    matching database_contracts.md's technical_evaluations table shape:
    evaluation_id, interview_id, scores_json, evaluation_notes, recommendation, completed_at.
    """
    evaluation_id: str
    interview_id: str
    candidate_id: str
    scores: List[CompetencyScore] = Field(default_factory=list)
    evaluation_notes: str = ""
    recommendation: Recommendation
    overall_score: float = Field(..., ge=0, le=10)
    confidence: float = Field(1.0, ge=0.0, le=1.0)
    source: str = Field("structured_ratings", description="'structured_ratings' or 'transcript_parsed'")
    completed_at: str = ""

    def scores_json(self) -> Dict[str, Any]:
        """The JSONB payload written to technical_evaluations.scores_json."""
        return {
            "categories": [s.model_dump() for s in self.scores],
            "overall_score": self.overall_score,
            "confidence": self.confidence,
            "source": self.source,
        }
