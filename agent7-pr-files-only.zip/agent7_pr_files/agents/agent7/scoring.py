"""
Deterministic scorecard math for Agent 7.

This module must never call Groq or any LLM. It exists to reconcile two
sources of truth that both apply here:

- Your original PROMPT-3 spec: a technical score must never be invented by
  an LLM — it must trace to explicit ratings and a fixed, published formula.
- This repo's agent_contracts.md §6: Agent 7 "parses interview transcripts
  and notes" and "generates competency scores."

The reconciliation: Groq (agents/agent7/groq_client.py) is only ever used to
*transcribe* an interviewer's free-text transcript into the same structured
rating fields a human would have typed directly — never to decide the score
itself. Whichever path produced the ratings (typed directly, or transcribed
from prose), the actual 0-10 overall_score always comes from this fixed
formula, and every transcript-derived scorecard is routed through the
WorkflowPaused / interviewer sign-off HITL gate (workflow_contracts.md §7)
before it's ever persisted.
"""
from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, List, Optional, Tuple

from agents.agent7.models import CompetencyScore, Recommendation

# Weights mirror PROMPT-3's original formula (technical/problem_solving/coding/system_design),
# renamed to this repo's four core technical_criteria buckets.
DEFAULT_WEIGHTS: Dict[str, float] = {
    "technical_depth": 0.40,
    "problem_solving": 0.30,
    "coding_proficiency": 0.20,
    "system_design": 0.10,
}

PASS_THRESHOLD = 6.0  # overall_score (0-10 scale) at/above this -> PASS


def round_half_up_1dp(x: float) -> float:
    return float(Decimal(str(x)).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP))


def compute_scorecard(
    ratings: Dict[str, Optional[float]],
    weights: Optional[Dict[str, float]] = None,
) -> Tuple[float, List[CompetencyScore], Dict[str, float]]:
    """
    ratings: {"technical_depth": 8.5, "problem_solving": 8.0, "coding_proficiency": 7.5,
              "system_design": None}  — each on a 0-10 scale; None means N/A for this round.

    Returns (overall_score_0_to_10, [CompetencyScore,...], weights_actually_used).
    """
    base_weights = dict(weights or DEFAULT_WEIGHTS)
    present = {k: float(v) for k, v in ratings.items() if v is not None}
    if not present:
        raise ValueError("No applicable competency ratings — cannot compute a scorecard.")

    excluded_weight = sum(base_weights[k] for k in base_weights if k not in present)
    remaining_base_total = sum(base_weights[k] for k in present)
    weights_used = {
        k: base_weights[k] + (excluded_weight * (base_weights[k] / remaining_base_total) if remaining_base_total else 0.0)
        for k in present
    }

    overall = sum(weights_used[k] * present[k] for k in present)
    overall = round_half_up_1dp(overall)
    overall = max(0.0, min(10.0, overall))

    scores = [CompetencyScore(category=k, score=present[k]) for k in present]
    return overall, scores, weights_used


def recommend(overall_score: float) -> Recommendation:
    return Recommendation.PASS if overall_score >= PASS_THRESHOLD else Recommendation.FAIL
