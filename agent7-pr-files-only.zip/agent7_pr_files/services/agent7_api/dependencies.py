from shared.registry.tool_registry import tool_registry
from mcp.database.client import DatabaseMCPClient
from mcp.resume.client import ResumeMCPClient
from mcp.analytics.client import AnalyticsMCPClient
from agents.agent7.agent import TechnicalInterviewAgent


def initialize_dependencies():
    """
    Composition root function registering the required MCP mock client classes
    in the global ToolRegistry. Per agent_contracts.md §6, Agent 7's allowed
    MCPs are: Database MCP, Resume MCP, Analytics MCP — no Calendar, Meet,
    Document, or Notification access (those belong to Agent 6).
    """
    _register_if_absent("database_mcp", DatabaseMCPClient)
    _register_if_absent("resume_mcp", ResumeMCPClient)
    _register_if_absent("analytics_mcp", AnalyticsMCPClient)


def _register_if_absent(tool_name: str, tool_class):
    try:
        tool_registry.get_tool(tool_name)
    except KeyError:
        tool_registry.register(tool_name, tool_class)


def get_agent7() -> TechnicalInterviewAgent:
    """FastAPI dependency injection provider returning a TechnicalInterviewAgent instance."""
    return TechnicalInterviewAgent()
