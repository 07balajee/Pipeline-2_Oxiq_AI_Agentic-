import uuid
from typing import Optional
from fastapi import APIRouter, Depends, Header, HTTPException, Response
from shared.context.workflow_context import WorkflowContext
from schemas.agent_response import AgentResponse
from agents.agent7.agent import TechnicalInterviewAgent
from services.agent7_api.dependencies import get_agent7

router = APIRouter()


@router.get("/health")
def get_health():
    """Health check endpoint. Returns operational status without triggering Agent 7."""
    return {"status": "healthy", "service": "agent7", "version": "v1"}


@router.post("/execute", response_model=AgentResponse)
def execute_agent(
    context: WorkflowContext,
    response: Response,
    x_correlation_id: Optional[str] = Header(None),
    x_idempotency_key: Optional[str] = Header(None),
    agent: TechnicalInterviewAgent = Depends(get_agent7)
) -> AgentResponse:
    """
    Executes the technical evaluation logic inside the reference Agent 7.
    Accepts WorkflowContext, validates inputs, resolves dependencies,
    and returns the AgentResponse — matching api_contracts.md §4.B exactly.
    """
    correlation_id = x_correlation_id or str(uuid.uuid4())

    response.headers["X-Correlation-ID"] = correlation_id
    if x_idempotency_key:
        response.headers["X-Idempotency-Key"] = x_idempotency_key

    if not context.metadata:
        context.metadata = {}
    context.metadata["correlation_id"] = correlation_id
    if x_idempotency_key:
        context.metadata["idempotency_key"] = x_idempotency_key

    try:
        agent_response = agent.run(context)
        return agent_response
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Unhandled internal service execution failure: {str(e)}"
        )
