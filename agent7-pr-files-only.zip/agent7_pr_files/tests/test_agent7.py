import unittest
from unittest.mock import patch

from shared.context.workflow_context import WorkflowContext
from shared.context.candidate_context import CandidateContext
from agents.agent7.agent import TechnicalInterviewAgent
from agents.agent7.tools import Agent7ToolsAdapter


class TestAgent7(unittest.TestCase):
    def setUp(self):
        self.agent = TechnicalInterviewAgent()
        self.candidate_data = {
            "candidate_id": "CAND-001",
            "name": "John Doe",
            "email": "john.doe@example.com",
            "resume_url": "CV_JohnDoe_AIEngineer.pdf",
            "screening_score": 91.0,
            "job_id": "job-abc-123",
            "job_title": "AI Engineer",
        }
        self.candidate_ctx = CandidateContext(**self.candidate_data)

        from shared.registry.tool_registry import tool_registry
        self.original_tools = dict(tool_registry._tools)
        from mcp.database.client import DatabaseMCPClient
        from mcp.resume.client import ResumeMCPClient
        from mcp.analytics.client import AnalyticsMCPClient
        tool_registry.register("database_mcp", DatabaseMCPClient)
        tool_registry.register("resume_mcp", ResumeMCPClient)
        tool_registry.register("analytics_mcp", AnalyticsMCPClient)

    def tearDown(self):
        from shared.registry.tool_registry import tool_registry
        tool_registry._tools = self.original_tools

    def _context(self, step_data=None, metadata=None, current_state="TechnicalInterviewPending"):
        return WorkflowContext(
            workflow_id="wf-test-agent7",
            candidate=self.candidate_ctx,
            current_state=current_state,
            step_data=step_data or {},
            metadata=metadata or {},
        )

    # --- Happy path: explicit structured ratings ---

    def test_structured_ratings_happy_path(self):
        context = self._context(step_data={
            "interview_id": "int-tech-001",
            "technical_depth": 8.5,
            "problem_solving": 8.0,
            "coding_proficiency": 7.5,
            "system_design": 7.0,
            "evaluation_notes": "Strong across the board.",
        })
        resp = self.agent.run(context)
        self.assertEqual(resp.execution_status, "SUCCESS")
        self.assertEqual(resp.generated_event, "TechnicalScoreSubmitted")
        self.assertEqual(resp.updated_state, "TechnicalInterviewCompleted")
        self.assertEqual(resp.metadata["recommendation"], "PASS")
        self.assertAlmostEqual(resp.metadata["overall_score"], 8.0, places=1)
        self.assertEqual(resp.metadata["source"], "structured_ratings")
        self.assertEqual(resp.metadata["confidence"], 1.0)

    def test_low_ratings_recommend_fail(self):
        context = self._context(step_data={
            "interview_id": "int-tech-001",
            "technical_depth": 3.0, "problem_solving": 2.5,
            "coding_proficiency": 3.0, "system_design": 2.0,
            "evaluation_notes": "Struggled with core concepts.",
        })
        resp = self.agent.run(context)
        self.assertEqual(resp.execution_status, "SUCCESS")
        self.assertEqual(resp.metadata["recommendation"], "FAIL")

    def test_na_component_reweights_correctly(self):
        """system_design=None -> excluded and its weight redistributed, per scoring.py."""
        context = self._context(step_data={
            "interview_id": "int-tech-001",
            "technical_depth": 9.0, "problem_solving": 9.0,
            "coding_proficiency": 9.0, "system_design": None,
            "evaluation_notes": "No system design round for this junior req.",
        })
        resp = self.agent.run(context)
        self.assertEqual(resp.execution_status, "SUCCESS")
        self.assertAlmostEqual(resp.metadata["overall_score"], 9.0, places=1)
        categories = {s["category"] for s in resp.metadata["scores"]}
        self.assertNotIn("system_design", categories)

    # --- Transcript / Groq path ---

    def test_transcript_path_pauses_for_signoff(self):
        transcript = (
            "Candidate demonstrated strong technical depth, I would rate technical 9. "
            "Problem solving was also excellent, problem solving 8. Coding exercise was solid, coding 8."
        )
        context = self._context(step_data={"interview_id": "int-tech-001", "transcript_text": transcript})
        resp = self.agent.run(context)
        self.assertEqual(resp.execution_status, "SUCCESS")
        self.assertIsNone(resp.generated_event)
        self.assertEqual(resp.updated_state, "WorkflowPaused")
        self.assertEqual(resp.suggested_action, "AWAIT_INTERVIEWER_SIGNOFF")
        self.assertIn("draft_scorecard", resp.metadata)
        self.assertEqual(resp.metadata["source"], "transcript_parsed")

    def test_transcript_path_persists_after_signoff(self):
        transcript = (
            "Candidate demonstrated strong technical depth, I would rate technical 9. "
            "Problem solving was also excellent, problem solving 8. Coding exercise was solid, coding 8."
        )
        context = self._context(
            step_data={"interview_id": "int-tech-001", "transcript_text": transcript},
            metadata={"interviewer_approved": True},
        )
        resp = self.agent.run(context)
        self.assertEqual(resp.execution_status, "SUCCESS")
        self.assertEqual(resp.generated_event, "TechnicalScoreSubmitted")
        self.assertEqual(resp.updated_state, "TechnicalInterviewCompleted")

    # --- Failure paths ---

    def test_missing_ratings_and_transcript_fails_cleanly(self):
        context = self._context(step_data={"interview_id": "int-tech-001"})
        resp = self.agent.run(context)
        self.assertEqual(resp.execution_status, "FAILED")
        self.assertTrue(len(resp.errors) > 0)

    def test_missing_interview_id_fails_validation(self):
        context = self._context(step_data={"technical_depth": 8.0})
        resp = self.agent.run(context)
        self.assertEqual(resp.execution_status, "FAILED")
        self.assertIn("interview_id", resp.errors[0])

    def test_unknown_interview_id_fails_db_read(self):
        context = self._context(step_data={
            "interview_id": "does-not-exist",
            "technical_depth": 8.0, "problem_solving": 8.0,
            "coding_proficiency": 8.0, "system_design": 8.0,
        })
        resp = self.agent.run(context)
        self.assertEqual(resp.execution_status, "FAILED")
        self.assertIn("not found", resp.errors[0])

    def test_invalid_workflow_state_rejected(self):
        context = self._context(
            step_data={"interview_id": "int-tech-001", "technical_depth": 8.0,
                       "problem_solving": 8.0, "coding_proficiency": 8.0, "system_design": 8.0},
            current_state="CandidateShortlisted",
        )
        resp = self.agent.run(context)
        self.assertEqual(resp.execution_status, "FAILED")
        self.assertIn("Invalid workflow state", resp.errors[0])

    # --- MCP failure handling ---

    @patch.object(Agent7ToolsAdapter, "read_interview")
    def test_database_mcp_failure_reported_cleanly(self, mock_read_interview):
        from schemas.mcp_response import MCPResponse
        mock_read_interview.return_value = MCPResponse(
            status="FAILED", mcp_name="DatabaseMCP", workflow_id="wf-test-agent7",
            trace_id="trace-1", execution_time_ms=1.0, errors=["Simulated DB outage"],
        )
        context = self._context(step_data={
            "interview_id": "int-tech-001",
            "technical_depth": 8.0, "problem_solving": 8.0,
            "coding_proficiency": 8.0, "system_design": 8.0,
        })
        resp = self.agent.run(context)
        self.assertEqual(resp.execution_status, "FAILED")
        self.assertIn("Simulated DB outage", str(resp.errors))


if __name__ == "__main__":
    unittest.main()
