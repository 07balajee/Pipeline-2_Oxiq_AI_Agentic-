import unittest
from unittest.mock import patch
from fastapi.testclient import TestClient
from services.agent7_api.app import app
from services.agent7_api.dependencies import initialize_dependencies
from schemas.agent_response import AgentResponse


class TestAgent7API(unittest.TestCase):
    def setUp(self):
        # TestClient() without `with` doesn't always trigger FastAPI's lifespan
        # hook depending on version, so register MCP clients explicitly here —
        # the real-run test below needs a populated ToolRegistry.
        initialize_dependencies()
        self.client = TestClient(app)
        self.candidate_data = {
            "candidate_id": "CAND-001",
            "name": "John Doe",
            "email": "john.doe@example.com",
            "resume_url": "CV_JohnDoe_AIEngineer.pdf",
            "screening_score": 91.0,
            "job_id": "job-abc-123",
            "job_title": "AI Engineer",
        }
        self.context_json = {
            "workflow_id": "wf-test-api-1",
            "candidate": self.candidate_data,
            "current_state": "TechnicalInterviewPending",
            "step_data": {
                "interview_id": "int-tech-001",
                "technical_depth": 8.5, "problem_solving": 8.0,
                "coding_proficiency": 7.5, "system_design": 7.0,
                "evaluation_notes": "Strong across the board.",
            },
            "metadata": {},
        }

    def test_health_endpoint(self):
        """GET /v1/agents/agent7/health must return HTTP 200 health metadata without running the agent."""
        response = self.client.get("/v1/agents/agent7/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {
            "status": "healthy", "service": "agent7", "version": "v1",
        })

    @patch("agents.agent7.agent.TechnicalInterviewAgent.run")
    def test_execute_agent7_happy_path(self, mock_run):
        """POST /v1/agents/agent7/execute happy path must return HTTP 200 and SUCCESS agent response."""
        mock_run.return_value = AgentResponse(
            execution_status="SUCCESS",
            generated_event="TechnicalScoreSubmitted",
            updated_state="TechnicalInterviewCompleted",
            summary="Technical scorecard finalized.",
            errors=[], warnings=[], suggested_action=None,
            metadata={"overall_score": 8.0, "recommendation": "PASS"},
        )
        response = self.client.post("/v1/agents/agent7/execute", json=self.context_json)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["execution_status"], "SUCCESS")
        self.assertEqual(data["generated_event"], "TechnicalScoreSubmitted")
        self.assertEqual(data["metadata"]["recommendation"], "PASS")

    def test_execute_agent7_real_run_end_to_end(self):
        """No mocking — exercises the real graph through the live HTTP boundary."""
        response = self.client.post("/v1/agents/agent7/execute", json=self.context_json)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["execution_status"], "SUCCESS")
        self.assertEqual(data["updated_state"], "TechnicalInterviewCompleted")
        self.assertAlmostEqual(data["metadata"]["overall_score"], 8.0, places=1)

    def test_execute_business_failure_returns_http_200(self):
        """
        Per api_contracts.md §2.A: a business-logic failure (e.g. missing
        interview_id) must still return HTTP 200 with execution_status=FAILED,
        never a 4xx/5xx.
        """
        bad_context = dict(self.context_json)
        bad_context["step_data"] = {"technical_depth": 8.0}  # no interview_id
        response = self.client.post("/v1/agents/agent7/execute", json=bad_context)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["execution_status"], "FAILED")
        self.assertTrue(len(data["errors"]) > 0)

    def test_correlation_and_idempotency_headers_propagated(self):
        response = self.client.post(
            "/v1/agents/agent7/execute",
            json=self.context_json,
            headers={
                "X-Correlation-ID": "corr-test-123",
                "X-Idempotency-Key": "idemp-a7-corr-test-123",
            },
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.headers.get("X-Correlation-ID"), "corr-test-123")
        self.assertEqual(response.headers.get("X-Idempotency-Key"), "idemp-a7-corr-test-123")

    def test_missing_required_field_returns_422(self):
        """Malformed payload (missing candidate) must fail Pydantic schema validation."""
        response = self.client.post("/v1/agents/agent7/execute", json={"workflow_id": "wf-bad"})
        self.assertEqual(response.status_code, 422)


if __name__ == "__main__":
    unittest.main()
